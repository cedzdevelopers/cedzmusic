/*
 * Copyright (c) 2020. Carlos René Ramos López. All rights reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.cedzlabs.cedzplayer.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.bundleOf
import androidx.recyclerview.widget.GridLayoutManager
import com.cedzlabs.cedzplayer.R
import com.cedzlabs.cedzplayer.alertdialog.actions.AlertItemAction
import com.cedzlabs.cedzplayer.alertdialog.enums.AlertItemTheme
import com.cedzlabs.cedzplayer.databinding.FragmentAlbumBinding
import com.cedzlabs.cedzplayer.extensions.*
import com.cedzlabs.cedzplayer.models.Album
import com.cedzlabs.cedzplayer.ui.adapters.AlbumAdapter
import com.cedzlabs.cedzplayer.ui.fragments.base.BaseFragment
import com.cedzlabs.cedzplayer.ui.viewmodels.AlbumViewModel
import com.cedzlabs.cedzplayer.utils.BeatConstants
import com.cedzlabs.cedzplayer.utils.BeatConstants.ALBUM_KEY
import com.cedzlabs.cedzplayer.utils.GeneralUtils
import com.cedzlabs.cedzplayer.utils.GeneralUtils.PORTRAIT
import com.cedzlabs.cedzplayer.utils.SortModes
import org.koin.android.ext.android.inject

class AlbumFragment : BaseFragment<Album>() {

    private lateinit var albumAdapter: AlbumAdapter
    private lateinit var binding: FragmentAlbumBinding
    private val albumViewModel by inject<AlbumViewModel>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = inflater.inflateWithBinding(R.layout.fragment_album, container)
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        init()
        retainInstance = true
    }

    private fun init() {
        val sc = if (GeneralUtils.getOrientation(safeActivity) == PORTRAIT) 2 else 5

        albumAdapter = AlbumAdapter(context).apply {
            showHeader = true
            itemClickListener = this@AlbumFragment
            spanCount = sc
        }

        binding.list.apply {
            layoutManager = GridLayoutManager(context, sc).apply {
                spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                    override fun getSpanSize(position: Int): Int {
                        return if (position == 0) sc else 1
                    }
                }
            }
            adapter = albumAdapter
        }

        albumViewModel.getAlbums()
            .filter { !albumAdapter.albumList.deepEquals(it) }
            .observe(this) { list ->
                albumAdapter.updateDataSet(list)
            }

        binding.let {
            it.viewModel = albumViewModel
            it.lifecycleOwner = this
            it.executePendingBindings()
        }

        createDialog()
    }

    private fun createDialog() {
        dialog = buildDialog(
            getString(R.string.sort_title),
            getString(R.string.sort_msg),
            listOf(
                AlertItemAction(
                    context!!.getString(R.string.sort_az),
                    settingsUtility.albumSortOrder == SortModes.AlbumModes.ALBUM_A_Z,
                    AlertItemTheme.DEFAULT
                ) {
                    it.selected = true
                    settingsUtility.albumSortOrder = SortModes.AlbumModes.ALBUM_A_Z
                    reloadAdapter()
                },
                AlertItemAction(
                    context!!.getString(R.string.sort_za),
                    settingsUtility.albumSortOrder == SortModes.AlbumModes.ALBUM_Z_A,
                    AlertItemTheme.DEFAULT
                ) {
                    it.selected = true
                    settingsUtility.albumSortOrder = SortModes.AlbumModes.ALBUM_Z_A
                    reloadAdapter()
                },
                AlertItemAction(
                    context!!.getString(R.string.sort_year),
                    settingsUtility.albumSortOrder == SortModes.AlbumModes.ALBUM_YEAR,
                    AlertItemTheme.DEFAULT
                ) {
                    it.selected = true
                    settingsUtility.albumSortOrder =
                        SortModes.AlbumModes.ALBUM_YEAR
                    reloadAdapter()
                },
                AlertItemAction(
                    context!!.getString(R.string.artist),
                    settingsUtility.albumSortOrder == SortModes.AlbumModes.ALBUM_ARTIST,
                    AlertItemTheme.DEFAULT
                ) {
                    it.selected = true
                    settingsUtility.albumSortOrder = SortModes.AlbumModes.ALBUM_ARTIST
                    reloadAdapter()
                },
                AlertItemAction(
                    context!!.getString(R.string.song_count),
                    settingsUtility.albumSortOrder == SortModes.AlbumModes.ALBUM_SONG_COUNT,
                    AlertItemTheme.DEFAULT
                ) {
                    it.selected = true
                    settingsUtility.albumSortOrder = SortModes.AlbumModes.ALBUM_SONG_COUNT
                    reloadAdapter()
                }
            )
        )
    }

    private fun reloadAdapter() {
        albumViewModel.update()
    }

    override fun onItemClick(view: View, position: Int, item: Album) {
        activity!!.addFragment(
            R.id.nav_host_fragment,
            AlbumDetailFragment(),
            BeatConstants.ALBUM_DETAIL,
            true,
            bundleOf(ALBUM_KEY to item.id)
        )
    }

    override fun onPopupMenuClick(view: View, position: Int, item: Album, itemList: List<Album>) {
        Toast.makeText(context, "Menu of " + item.title, Toast.LENGTH_SHORT).show()
    }

    override fun onPlayAllClick(view: View) {
        Toast.makeText(context, "Shuffle", Toast.LENGTH_SHORT).show()
    }

    override fun onSortClick(view: View) {
        dialog.show(activity as AppCompatActivity)
    }
}
